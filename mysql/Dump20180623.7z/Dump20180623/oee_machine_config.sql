-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: oee
-- ------------------------------------------------------
-- Server version	5.5.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `machine_config`
--

DROP TABLE IF EXISTS `machine_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `machine_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_code` varchar(10) NOT NULL,
  `chart_tooltip_desc` varchar(50) DEFAULT NULL,
  `chart_sql` text,
  `inserted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `mobile_sql` text,
  PRIMARY KEY (`id`),
  KEY `machine_config_idx` (`machine_code`),
  CONSTRAINT `fk_machine_config` FOREIGN KEY (`machine_code`) REFERENCES `machine_data` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `machine_config`
--

LOCK TABLES `machine_config` WRITE;
/*!40000 ALTER TABLE `machine_config` DISABLE KEYS */;
INSERT INTO `machine_config` (`id`, `machine_code`, `chart_tooltip_desc`, `chart_sql`, `inserted_at`, `mobile_sql`) VALUES (1,'MAQ6','Temperatura: __value °C','\n select date_format(f.inserted_at, \'%H:%i:%s\') as labels  \n 	  , f.field3 as data    \n      , coalesce((select chart_tooltip_desc from machine_config where machine_code = f.mc_cd), chart_tooltip_desc, \'\') as chart_tooltip_desc\n   from feed f\n  inner join channel c on c.id = f.ch_id\n  inner join machine_data md on md.code = f.mc_cd\n  inner join feed_config fc on fc.channel_id = c.id\n  where date_format(f.inserted_at, \'%d/%m/%Y %H:%i\') between \'__date_ini\' and \'__date_fin\'\n    and ch_id = __ch_id\n    and mc_cd = \'__mc_cd\'\n  order by f.inserted_at','2018-06-18 17:44:55','\nselect f.id\n	 , f.ch_id\n	 , f.mc_cd\n     , coalesce(md.mobile_name, md.code) as mobile_name\n	 , coalesce(f.field3, 0) as field3\n	 , date_format(f.inserted_at, \'%H:%i:%s\') as time  \n	 , concat(coalesce(f.field3, 0), \'°C\') as oee\n     , coalesce(fc.field3, \'campo 3: \') as field3_desc         \n  from feed f\n inner join channel_machine cm on cm.channel_id = f.ch_id and cm.machine_code = f.mc_cd\n inner join user_channel uc on uc.channel_id = cm.channel_id\n inner join feed_config fc on fc.channel_id = f.ch_id\n inner join machine_data md on md.code = f.mc_cd\n where uc.user_id = __user_id\n   and DATE_FORMAT(f.inserted_at, \'%d%m%Y\') = \'__date\'\n   and uc.channel_id = __ch_id\n   and cm.machine_code = \'__mc_cd\'\n order by f.inserted_at desc\n limit __limit'),(2,'MAQ10','Unidades de balões: __value',NULL,'2018-06-18 17:44:55',NULL),(3,'MAQ11','Unidades de balões: __value',NULL,'2018-06-18 17:44:55',NULL),(4,'MAQ12','Temperatura: __value °C','\n select date_format(f.inserted_at, \'%H:%i:%s\') as labels  \n 	  , f.field3 as data    \n      , coalesce((select chart_tooltip_desc from machine_config where machine_code = f.mc_cd), chart_tooltip_desc, \'\') as chart_tooltip_desc\n   from feed f\n  inner join channel c on c.id = f.ch_id\n  inner join machine_data md on md.code = f.mc_cd\n  inner join feed_config fc on fc.channel_id = c.id\n  where date_format(f.inserted_at, \'%d/%m/%Y %H:%i\') between \'__date_ini\' and \'__date_fin\'\n    and ch_id = __ch_id\n    and mc_cd = \'__mc_cd\'\n  order by f.inserted_at','2018-06-18 17:44:55','\nselect f.id\n	 , f.ch_id\n	 , f.mc_cd\n     , coalesce(md.mobile_name, md.code) as mobile_name\n	 , coalesce(f.field3, 0) as field3\n	 , date_format(f.inserted_at, \'%H:%i:%s\') as time  \n	 , concat(coalesce(f.field3, 0), \'°C\') as oee\n     , coalesce(fc.field3, \'campo 3: \') as field3_desc         \n  from feed f\n inner join channel_machine cm on cm.channel_id = f.ch_id and cm.machine_code = f.mc_cd\n inner join user_channel uc on uc.channel_id = cm.channel_id\n inner join feed_config fc on fc.channel_id = f.ch_id\n inner join machine_data md on md.code = f.mc_cd\n where uc.user_id = __user_id\n   and DATE_FORMAT(f.inserted_at, \'%d%m%Y\') = \'__date\'\n   and uc.channel_id = __ch_id\n   and cm.machine_code = \'__mc_cd\'\n order by f.inserted_at desc\n limit __limit'),(5,'MAQ13','Temperatura: __value °C','\n select date_format(f.inserted_at, \'%H:%i:%s\') as labels  \n 	  , f.field3 as data    \n      , coalesce((select chart_tooltip_desc from machine_config where machine_code = f.mc_cd), chart_tooltip_desc, \'\') as chart_tooltip_desc\n   from feed f\n  inner join channel c on c.id = f.ch_id\n  inner join machine_data md on md.code = f.mc_cd\n  inner join feed_config fc on fc.channel_id = c.id\n  where date_format(f.inserted_at, \'%d/%m/%Y %H:%i\') between \'__date_ini\' and \'__date_fin\'\n    and ch_id = __ch_id\n    and mc_cd = \'__mc_cd\'\n  order by f.inserted_at','2018-06-18 17:44:56','\nselect f.id\n	 , f.ch_id\n	 , f.mc_cd\n     , coalesce(md.mobile_name, md.code) as mobile_name\n	 , coalesce(f.field3, 0) as field3\n	 , date_format(f.inserted_at, \'%H:%i:%s\') as time  \n	 , concat(coalesce(f.field3, 0), \'°C\') as oee\n     , coalesce(fc.field3, \'campo 3: \') as field3_desc         \n  from feed f\n inner join channel_machine cm on cm.channel_id = f.ch_id and cm.machine_code = f.mc_cd\n inner join user_channel uc on uc.channel_id = cm.channel_id\n inner join feed_config fc on fc.channel_id = f.ch_id\n inner join machine_data md on md.code = f.mc_cd\n where uc.user_id = __user_id\n   and DATE_FORMAT(f.inserted_at, \'%d%m%Y\') = \'__date\'\n   and uc.channel_id = __ch_id\n   and cm.machine_code = \'__mc_cd\'\n order by f.inserted_at desc\n limit __limit');
/*!40000 ALTER TABLE `machine_config` ENABLE KEYS */;
UNLOCK TABLES;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-23 11:39:54
